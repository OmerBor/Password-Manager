

  
		var wsUri = "ws://127.0.0.1:8000/";
		var output;
		var myWebSocket;
		var loggedIn;
		var logged_user;
		var logged_pass;
  
  
  
		var myUsername;
		var myPassword; 
		var serverPass;
		var encryptionKey;
		var authenticationKey;
		var recievedMessage;
		var myHash;
		var sendTo;
		var ciphertext;
		var sentResponse;
		
		
		
		
	var passwordMap={ 
		passwordArray:[]
	}
	
	
	function makeDerivedPassword(password){ //return server password
		serverPass=makeServerPassword(password);
		encryptionKey=makeEncKey(password);
		authenticationKey=makeAuthKey(password);
	}	
	
	
	

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
	  sendTo=sendResponse;
    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");
   
	if (request.register != null){
      handleRegister(request.register);
	}
	if (request.login != null){
      handleLogin(request.login);
	}
	if (request.get != null){
      handleGetInformation();
	}
	if (request.send != null){
      handleSendInformation(request.send);
	}
	if (request.logout != null){
      handleLogOut();
	}
	if (request.open_popup != null){
      handleOpenPopup();
	}
	if (request.entry != null){
      handleConentEntry(request.entry);
	}
	if (request.searchURL != null){
      handleSearchURL(request.searchURL, sendTo);
	}
	return true; //for async
  });
	
	function dontSend(x){}
	function handleSearchURL(url, sendTo){
		//check url in table for content script
		//returns table entry if found
		sendToBackup=sendTo;
		if (!checkLogin()) {
			sendTo=dontSend;
			handleOpenPopup();
			handleGetInformation();
		}
		sendTo=sendToBackup;
		var toReturn= searchURL(url);
		if(toReturn!=null) sendTo(toReturn);
		else sendTo({result: "not found"});
	}
	
	
	function searchURL(url){
		if (passwordMap!=null){
			var array= passwordMap.passwordArray;
			for(var i=0; i<array.length; i++){
				if (array[i].Service==url)
					return {result: array[i]};
												
			}
			return null;
						
		}
		
	}
	
	
		
	
	function updateEntry(entry){
		//updates an existing table entry by the Service field
		if (passwordMap!=null){
			var array= passwordMap.passwordArray;
			for(var i=0; i<array.length; i++){
				if (array[i].Service==entry.Service){
					array[i].user=entry.user;
					array[i].password=entry.password;
					return true;		
				}
			}
									
		}
		return false;
	}
	
	
	
	
	
	function handleConentEntry(entry){
		//updates and existing entry or pushes new entry to password table
		//entry given by message from content script
		console.log("handleConentEntry Event");
		console.log(JSON.stringify(entry));
		
		handleOpenPopup(function(){
			if(updateEntry(entry)==false)
				passwordMap.passwordArray.push(entry);
			sentResponse=true;
			handleSendInformation(passwordMap)
		});
				
		
			// myHash = CryptoJS.HmacSHA256(ciphertext, authenticationKey).toString();
		//handleSendInformation(passwordMap);
	}
	
	



  
	
	function handleOpenPopup(callback){
		//popup opens- connect and get information
		console.log("popup open Event");
		chrome.storage.local.get(['loggedIn'], function(result) {
			console.log('loggedIn currently is ' + result.loggedIn);
			loggedIn=result.loggedIn;
			
			chrome.storage.local.get(['serverPass'], function(result) {
			console.log('serverPass currently is ' + result.serverPass);
			serverPass=result.serverPass;
			
				chrome.storage.local.get(['encryptionKey'], function(result) {
				console.log('encryptionKey currently is ' + result.encryptionKey);
				encryptionKey=result.encryptionKey;
				
								
						
				chrome.storage.local.get(['authenticationKey'], function(result) {
				console.log('authenticationKey currently is ' + result.authenticationKey);
				authenticationKey=result.authenticationKey;
				
				
					chrome.storage.local.get(['logged_user'], function(result) {
					console.log('logged_user currently is ' + result.logged_user);
					logged_user=result.logged_user;
					
					
					
					if(loggedIn==true){
						if(myWebSocket==null){
						createWebSocket(wsUri);
						myWebSocket.onopen=()=>myWebSocket.send(makeFrame("login",logged_user,serverPass));
						}
						else {
							myWebSocket.send(makeFrame("login",logged_user,serverPass));
								if(callback!=null) callback();
							}
				
					}
					else sendTo({result: false});
				
		
		
					
					});
				});
				});
				
			});
					
		});
		
	
	
	
	}
	
	
	
	
	
	function handleRegister(array){ //regiser {user:pass} array[user, pass]
		console.log("register Event");
		makeDerivedPassword(array[1]);
		if(myWebSocket==null){
			createWebSocket(wsUri);
			myWebSocket.onopen=()=>myWebSocket.send(makeFrame("register",array[0],serverPass));
		}
		else myWebSocket.send(makeFrame("register",array[0],serverPass));
			
	}
	function handleLogin(array){ //login {user:pass} array[user, pass]
		console.log("login Event");
		makeDerivedPassword(array[1]);
		if(myWebSocket==null){
			createWebSocket(wsUri);
			myWebSocket.onopen=()=>myWebSocket.send(makeFrame("login",array[0],serverPass));
		}
		else myWebSocket.send(makeFrame("login",array[0],serverPass));
		myUsername=array[0];
		//myPassword=array[1];
		
	}
	
	function handleGetInformation(){ //get
		console.log("GetInformation Event");
		if(myWebSocket==null){
				console.log("error: not connected");
				sendTo("error");
			}
			else {
				console.log("sending data");
				myWebSocket.send("get");  //server format for saving
			
			}
		//sendResponse({result: "GetInformation result from background script"});
	}
	
	
	function handleSendInformation(userTable){ //save *json*
	
		console.log("sendInformation Event");
		//if(loggedIn=="true"){
			//sendResponse({result: "sendInformation result from background script"});
			
			 ciphertext = CryptoJS.AES.encrypt(JSON.stringify(userTable),encryptionKey).toString(); //cbc by default
			 myHash = CryptoJS.HmacSHA256(ciphertext, authenticationKey).toString();
			console.log("cypher text: "+ciphertext+" hashed value from message : "+myHash+"key: "+authenticationKey);
			console.log("encKey: "+encryptionKey);
			var jsInfo= {mac: myHash, info: ciphertext}; 
		
			if(myWebSocket==null){
				console.log("error: not connected");
				sendTo("error");
			}
			else {
				console.log("sending data");
				myWebSocket.send("save"+JSON.stringify(jsInfo));  //server format for saving
			
			}
		//}
		//else sendTo("error");
	}
	
	function handleLogOut(){
			console.log("logout Event");
			if(myWebSocket!=null)
				myWebSocket.close();
			chrome.browserAction.setIcon({path: "/images/icon2.png"});
			myWebSocket=null;
			myUsername=null;
			myPassword=null;
			sendTo({result: "ok"});
			chrome.storage.local.set({loggedIn: false}, function() {});
			chrome.storage.local.set({serverPass: null}, function() {});
			chrome.storage.local.set({encryptionKey: null}, function() {});
			chrome.storage.local.set({authenticationKey: null}, function() {});
			 chrome.storage.local.set({logged_user: null}, function() {
					console.log('user is set to ' + myUsername);
						});
	}
	
	
	function makeServerPassword(password){ //return server password
		return CryptoJS.SHA256(password.concat('1')).toString();
	
	}	
	function makeEncKey(password){ //return server password
		return CryptoJS.SHA256(password.concat('2')).toString();
	
	}	
	function makeAuthKey(password){ //return server password
		return CryptoJS.SHA256(password.concat('3')).toString();
	}
		
		
 
 


function checkLogin(){
	return loggedIn===true;
	
}

function checkConnection(){
	return (!(myWebSocket===null));
}


function makeFrame(action, username, password){
	return action+'{"'+username+'":"'+password+'"}';
}




function createWebSocket(wsUri){
	
	myWebSocket = new WebSocket(wsUri);
		
	// Connection opened
	myWebSocket.addEventListener('open', function (event) {
		console.log("connection open");
    });

	// Listen for messages
	myWebSocket.addEventListener('message', function (event) {
				console.log("background recieved message from socket: "+event.data)
				//if(loggedIn==false) 
				if (event.data === 'approve') {
					chrome.browserAction.setIcon({path: "/images/icon1.png"});
					if(loggedIn!=true){
						sendTo({result: "ok"});
						chrome.storage.local.set({loggedIn: true}, function() {
						console.log('login is set to ' + true);
						});
						loggedIn=true;
						chrome.storage.local.set({serverPass: serverPass}, function() {});
						chrome.storage.local.set({encryptionKey: encryptionKey}, function() {});
						chrome.storage.local.set({authenticationKey: authenticationKey}, function() {});
						 chrome.storage.local.set({logged_user: myUsername}, function() {
						console.log('user is set to ' + myUsername);
						});
					
						console.log('connection approved, save cerd and hide form');
					}
					else{
						sendTo({result: "ok"});
						//handleGetInformation();
						
					}
				      
				}
			else if(event.data=="Username already exist") {
				console.log("wrong username or password");
				chrome.storage.local.set({loggedIn: false}, function() {
						console.log('login is set to ' + true);
				});
				sendTo({result: "errorU"});
				//send message to popup
			}
			else if(event.data== 'denied') {
				console.log("wrong username or password");
				chrome.storage.local.set({loggedIn: false}, function() {
						console.log('login is set to ' + true);
				});
				sendTo({result: "error"});
				//send message to popup
			}
			else if(event.data== 'register OK' ) {
				sendTo({result: "ok"});
				//send message to popup
			
			}
			else if(event.data== 'saved' ) {
				if(sentResponse!=true) sendTo({result: "ok"});
				//send message to popup
			}
			else if(event.data.substring(0, 4) =="info") { //get message -  respone from server with information
				if(event.data!="info"){
					var data=event.data.substring(4);
					console.log(data);
					
					if (checkData(data)){
					var jsonData=decryptInformation(data);
						passwordMap=jsonData;
						sendTo({result: passwordMap});
					}
					else {
						sendTo({result: "errorA"});
						console.log("authenticating failure");
					}
				}
				else sendTo({result: "empty"});
				//send data to popup
								
			}
	});
	 
	myWebSocket.addEventListener('error', function (event) {
			console.log("connection error");
			if(sendTo!=null)
					sendTo({result: "error"});
		//myWebSocket.close();
		myWebSocket = null;
	});
	
	myWebSocket.addEventListener('close', function (event) {
			console.log("connection close");
			chrome.browserAction.setIcon({path: "/images/icon2.png"});
		myWebSocket = null;
	});
}


function checkData(data){
	//check MAC
	data=JSON.parse(data);
	myHash= data.mac;
	var info= data.info;
	console.log("mac: "+ myHash);
	console.log("info: "+ info);
	var recievedHashMac = CryptoJS.HmacSHA256(info, authenticationKey).toString();
	console.log("key: "+authenticationKey);
	console.log("hash on messge: "+recievedHashMac);
	if( myHash===recievedHashMac) {
		return true;
	}
	else return false;
	
}

function decryptInformation(data){
	data=JSON.parse(data);
	var info= data['info']
	console.log("decrypting information");
	console.log("encryptionKey : "+encryptionKey);
	var bytes  = CryptoJS.AES.decrypt(info, encryptionKey);  
	var decryptedData = bytes.toString(CryptoJS.enc.Utf8);  //maybe already sent string
	console.log(decryptedData);
	return JSON.parse(decryptedData);
}

