
var passwordElement;
var userElement;
var submitButton;	
var formElement;
var loadedPage;
var toSave;
var children;
var username;
var password;


		

window.addEventListener ("load", myMain, false);


function myMain (evt) {
	
	var currentNode,
    ni = document.createNodeIterator(document.documentElement, NodeFilter.SHOW_ELEMENT);
	while(currentNode = ni.nextNode()) {
		if(currentNode.type=="password") {
			  console.log("found password: "+currentNode.name);
			  passwordElement=currentNode;
			  break;
			
			}
	}
	currentNode,
    ni = document.createNodeIterator(document.documentElement, NodeFilter.SHOW_ELEMENT);

	while(currentNode = ni.nextNode()) {
		if((currentNode.tagName== "FORM")&&(currentNode.contains(passwordElement))) {
			currentNode.onsubmit = sendSubmit;
			console.log("found form containing password");
			formElement=currentNode;
				break;
		}
	}	
		 
		if(loadedPage==null){
			if (formElement!=null){
				const formIterator = document.createNodeIterator(formElement, NodeFilter.SHOW_ELEMENT);
				while(currentNode = formIterator.nextNode()) {
				if((currentNode.type=="email")||(currentNode.type=="text") ) {
					userElement=currentNode;
					console.log("found username input: "+ currentNode.nodeName+ ":" + currentNode.textContent);
				}
				if(currentNode.tagName=="BUTTON"){
					console.log("stick onclick to this button: " + currentNode.nodeName+ ":" + currentNode.textContent);
				}
			//console.log(currentNode);
			}
		}
			
			loadedPage=true;
		
		}
		//checks if user is logged in and there is an table entry for the current URL
		//fills the forms if found
		chrome.storage.local.get(['loggedIn'], function(result) {
			console.log('loggedIn currently is ' + result.loggedIn);
			if(result.loggedIn==true)
				chrome.runtime.sendMessage({searchURL:  window.location.hostname}, function(response) {
					if (response.result!="not found"){
						
					
							userElement.value=response.result.user;
							passwordElement.value=response.result.password;
							username=response.result.user;
							password=response.result.password;
					
						
					}
					
					
					
				});
		});
		
		
		
		
		
		
	}
function sendSubmit(){
	//passes information to background script 
	if(passwordElement!=null){
		
		if((password!=passwordElement.value) || (username!= userElement.value)){
			console.log("submit");
			console.log("username: "+ userElement.value+ " password: "+ passwordElement.value);
			console.log(window.location.hostname);
			var toAdd= {
				Service: window.location.hostname,
				user: userElement.value,
				password:  passwordElement.value
			}
			if(password==null)
				chrome.runtime.sendMessage({entry: toAdd}, function(response) {});
			else if (confirm("Save cerdentials?")) {
				chrome.runtime.sendMessage({entry: toAdd}, function(response) {});
			} 
		}
	}
};











