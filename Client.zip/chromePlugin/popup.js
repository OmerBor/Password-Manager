
  
  

  var output;
	var deleteButton;
	var myWebSocket;
	var loggedIn;
  	var logged_user;
	var logged_pass;
function functionOnLoad() {
		chrome.runtime.sendMessage({open_popup: "open_popup"}, function(response) {
		console.log(response.result);
		if(response.result=="ok") {
			document.getElementById("loginForm").style.display="none";
			document.getElementById("registerButton").style.display="none";
			document.getElementById("sentMessages").innerHTML="";
			document.getElementById("logOutButton").style.display="";
			document.getElementById("sendButton").style.display="";
			document.getElementById("recieveButton").style.display="";
			document.getElementById("plusButton").style.display="";
			handle_RECIEVE();
		}
		else if(response.result=="error")
			document.getElementById("messageText").innerHTML="ERROR while trying to login";
		});
			  
}
window.onload =functionOnLoad;
 

	var passwordMap;
		var activeTR;
		var activeTRbg;
	 // INIT
		var myUsername   = document.getElementById("userNameInput").value
		var myPassword = document.getElementById("passwordInput").value;
		//local files
		var messageToEncrypt="message to be encrypted";
		document.getElementById("usernameDebug").innerHTML = myUsername;
		document.getElementById("password").innerHTML = myPassword;
				document.getElementById("message").innerHTML = messageToEncrypt;
		var serverPass=CryptoJS.SHA256(myPassword.concat('1')).toString();
		document.getElementById("passwordToServer").innerHTML = serverPass;
		var encryptionKey= CryptoJS.SHA256(myPassword.concat('2')).toString();
		document.getElementById("encryptionKey").innerHTML =encryptionKey;
		var authenticationKey=CryptoJS.SHA256(myPassword.concat('3')).toString();
		document.getElementById("authenticationKey").innerHTML =authenticationKey ;
		var recievedMessage= "not initialized";
		var myHash="not initialized";



  document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("registerButton").addEventListener("click", handlerREGISTER);
});
  
  function handlerREGISTER(){
	  
		  
	myUsername = document.getElementById("userNameInput").value;
	myPassword = document.getElementById("passwordInput").value;
	
	chrome.runtime.sendMessage({register: [myUsername, myPassword]}, function(response) {
		console.log("resgister result:"+ response.result);
		if(response.result=="ok")
			document.getElementById("sentMessages").innerHTML="user registered";
		else if(response.result=="error")
			document.getElementById("messageText").innerHTML="ERROR while trying to register";
		else if(response.result=="errorU")
			document.getElementById("messageText").innerHTML="ERROR username already exist";
		}); 
		
	
		
	  	
		
  }
  
  
  document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("debugButton").addEventListener("click", handler_DEBUG);
});
 
function handler_DEBUG(){
	
	clearTable();
	document.getElementById("debugLabel").style.display='';
		myUsername   = document.getElementById("userNameInput").value;
		myPassword = document.getElementById("passwordInput").value;
		
		messageToEncrypt="message to be encrypted";
		document.getElementById("usernameDebug").innerHTML = myUsername;
		document.getElementById("password").innerHTML = myPassword;
		
		
	makePasswordTableFromJSON(passwordMap, document.getElementById("tablePasswords"));
	
}
		
		
document.addEventListener('DOMContentLoaded', function() {
document.getElementById("debugCloseButton").addEventListener("click", handler_DEBUG_CLOSE);
});
 
function handler_DEBUG_CLOSE(){
	document.getElementById("debugLabel").style.display='none';
}



  document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("loginButton").addEventListener("click", handler_LOGIN);
});
 
function handler_LOGIN(){
	
	myUsername = document.getElementById("userNameInput").value;
	myPassword = document.getElementById("passwordInput").value;
	chrome.runtime.sendMessage({login: [myUsername, myPassword]}, function(response) {
		console.log("login result:"+ response.result);
		if(response.result=="ok") {
			document.getElementById("loginForm").style.display="none";
			document.getElementById("registerButton").style.display="none";
			document.getElementById("sentMessages").innerHTML="";
			document.getElementById("logOutButton").style.display="";
			document.getElementById("sendButton").style.display="";
			document.getElementById("recieveButton").style.display="";
			document.getElementById("plusButton").style.display="";
			document.getElementById("tableHeader").style.display="";
			document.getElementById("messageText").innerHTML="";
			handle_RECIEVE();
		}
		else if(response.result=="error")
				document.getElementById("messageText").innerHTML="ERROR: wrong username or password";
			
		
		
		
	}); 
	
	  
	document.getElementById("usernameDebug").innerHTML = myUsername; //for debug
	document.getElementById("password").innerHTML = myPassword; //for debug.
	}


  document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("recieveButton").addEventListener("click", handle_RECIEVE);
});
 
function handle_RECIEVE(){
	
	chrome.runtime.sendMessage({get: "get"}, function(response) {
		if((response.result!="error")&&(response.result!="errorA")&&(response.result!="empty")){
			console.log("get result:"+ JSON.stringify(response.result));
			clearTable();
			makePasswordTableFromJSON(response.result, document.getElementById("tablePasswords"));
				document.getElementById("tablePasswords").style.display="";
				document.getElementById("tableHeader").style.display="";
		}
		else if(response.result=="error")
				document.getElementById("messageText").innerHTML="ERROR recieving data";
		else if(response.result=="errorU")
				document.getElementById("messageText").innerHTML="ERROR recieving data";
		else if(response.result=="errorA"){
				document.getElementById("infoError").innerHTML="ERROR! Your content has been modified in the server!";
				
		}
	});
	
	
}

 document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("sendButton").addEventListener("click", handleSend);
});
 
function handleSend(){
	var table=document.getElementById("tablePasswords");
	var toSend=tableToJSON(table);
	if (toSend!="empty")
		chrome.runtime.sendMessage({send: toSend}, function(response) {
			console.log("send information result:"+ response.result);
			if(response.result=="error")
				document.getElementById("messageText").innerHTML="Authentication Error, Data from server is not valid";
		}); 
	
}
 document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("logOutButton").addEventListener("click", handle_logOut);
});

function handle_logOut(){
		chrome.runtime.sendMessage({logout: "logout"}, function(response) {
		console.log("logout result:"+ response.result);
		if(response.result="ok"){
			document.getElementById("loginForm").style.display="";
			document.getElementById("registerButton").style.display="";
			document.getElementById("sendButton").style.display="none";
			document.getElementById("recieveButton").style.display="none";
			document.getElementById("logOutButton").style.display="none";
			document.getElementById("tablePasswords").style.display="none";
			document.getElementById("tableHeader").style.display="none";
			document.getElementById("plusButton").style.display="none";
			document.getElementById("infoError").style.display="none";
			clearTable();
			
		}
			
		}); 
		
}

 document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("plusButton").addEventListener("click",handle_addEntry );
});

function handle_addEntry(){
		
		addNewEntry();
		document.getElementById("tablePasswords").style.display="";
		
}



function checkLogin(){
	return loggedIn===true;
	
}


function handle_delete(tr){
	var table=document.getElementById("tablePasswords");
	tr.remove();
	if (table.rows.length==0) table.style.display="none";
}



function handle_markRow(tr){
	document.getElementById("minusButton").style.display="";
	tr.style.backgroundColor = "#ffdefe";
	
	console.log(tr.id);
	document.getElementById("minusButton").addEventListener("click",function(){handle_delete(tr);} );
	
		
}


function addNewEntry3(s1, s2, s3){
	var table=document.getElementById("tablePasswords");
	 var tr = document.createElement("tr"); //table row
	  var td = document.createElement("td"); //table cell
	var txt = document.createTextNode(s1);
	txt.contenteditable="true";
	td.className = "tdStyle"; //table
	td.appendChild(txt);
	tr.appendChild(td);
	txt = document.createTextNode( s2);
	txt.contenteditable="true";
	td = document.createElement("td"); //table cell
	td.className = "tdStyle"; //table cell
	td.appendChild(txt);
	tr.appendChild(td);
	txt = document.createTextNode(s3);
	txt.contenteditable="true";
	td = document.createElement("td"); //table cell
	td.className = "tdStyle"; //table
	td.appendChild(txt);
	tr.appendChild(td);
	tr.className = "trStyle"; //table
	tr.addEventListener("click", function(e){
		

		var b = document.getElementById("minusButton"),
		bClone = b.cloneNode(true);
		b.parentNode.replaceChild(bClone, b);
			
		if(activeTR!=null)
			activeTR.style.backgroundColor = activeTRbg;
		activeTR=tr;
		activeTRbg=activeTR.style.backgroundColor;
		e.stopPropagation();
		handle_markRow(tr);
		document.body.addEventListener("click", function(){
			activeTR.style.backgroundColor = activeTRbg;
			document.getElementById("minusButton").style.display="none";
			var b = document.getElementById("minusButton"),
				bClone = b.cloneNode(true);
				b.parentNode.replaceChild(bClone, b);
			
		
		}, {once : true});
				
		});
	table.appendChild(tr);
}

function addNewEntry(){
	var table=document.getElementById("tablePasswords");
	 var tr = document.createElement("tr"); //table row
	  var td = document.createElement("td"); //table cell
	var txt = document.createTextNode("");
	txt.contenteditable="true";
	td.className = "tdStyle"; //table
	td.appendChild(txt);
	tr.appendChild(td);
	txt = document.createTextNode("");
	txt.contenteditable="true";
	td = document.createElement("td"); //table cell
	td.className = "tdStyle"; //table cell
	td.appendChild(txt);
	tr.appendChild(td);
	txt = document.createTextNode("");
	txt.contenteditable="true";
	td = document.createElement("td"); //table cell
	td.className = "tdStyle"; //table
	td.appendChild(txt);
	tr.appendChild(td);
	tr.className = "trStyle"; //table
	tr.addEventListener("click", function(e){
		
				var b = document.getElementById("minusButton"),
				bClone = b.cloneNode(true);
				b.parentNode.replaceChild(bClone, b);
			
		if(activeTR!=null)
			activeTR.style.backgroundColor = activeTRbg;
		activeTR=tr;
		activeTRbg=activeTR.style.backgroundColor;
		e.stopPropagation();
		handle_markRow(tr);
		document.body.addEventListener("click", function(){
			activeTR.style.backgroundColor = activeTRbg;
			document.getElementById("minusButton").style.display="none";
				var b = document.getElementById("minusButton"),
				bClone = b.cloneNode(true);
				b.parentNode.replaceChild(bClone, b);
			
	
		}, {once : true});
				
		});
	table.appendChild(tr);
}


function makePasswordTableFromJSON(passwordMap,table){
	var pArray=passwordMap.passwordArray;
	var tr;
	var td;
	var txt;
	var ndx=0;
	console.log(JSON.stringify(pArray));
	for (var i in pArray) {
		addNewEntry3(pArray[i].Service, pArray[i].user, pArray[i].password);
		
	}
	
}

function tableToJSON(table){
	var rowCount = table.rows.length;
	console.log("rows: "+table.rows.length);
	var array= [];
	if(rowCount==0)
		return "empty";
	else{
		for (var i = 0; i<rowCount; i++) {
			var row=table.rows[i];
			var entry={
			Service: row.cells[0].innerHTML, 	
			user: row.cells[1].innerHTML,
			password: row.cells[2].innerHTML 				
			};
			array.push(entry);
			console.log("found row in loop");
			for (var j = 0;j<row.cells.length; j++) {
			var col=row.cells[j];
			
			  console.log("found cell in loop: "+col.innerHTML);
				 //iterate through columns
				 //columns would be accessed using the "col" variable assigned in the for loop
			}  
		}
		var map={passwordArray: array};
		console.log(JSON.stringify(map));
		return map;
	}
	
	
}

function clearTable(){
	var elmtTable = document.getElementById('tablePasswords');
		var tableRows = elmtTable.getElementsByTagName('tr');
		var rowCount = tableRows.length;
		for (var x=rowCount-1; x>=0; x--) {
			elmtTable.removeChild(tableRows[x]);
		}
	
}


